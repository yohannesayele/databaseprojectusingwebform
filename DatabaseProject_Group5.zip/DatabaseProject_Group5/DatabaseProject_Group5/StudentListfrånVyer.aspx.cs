﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowEleverfråmVyer();
            }
        }

        private void ShowEleverfråmVyer()
        {
             SqlDataReader reader = null;

            try
            {
                Database db = new Database();
                if (db.Connect())
                {
                    reader = db.GetDataReader("SELECT * FROM ELEVER_LISTA");
                }
                else
                {
                    throw new Exception("Database connection error.");
                }

                if (reader != null)
                {
                    lrlEleverVyer.Text = "<h2>ELEVER_LISTA</h2>";
                    while (reader.Read())
                    {
                        ReadSingleRow((IDataRecord)reader);
                    }
                }
                else
                {
                    lrlEleverVyer.Text = "Det finns ingen data!";
                }
            }
            catch (Exception ex)
            {
                lrlEleverVyer.Text = ex.Message;
            }

        }
        private void ReadSingleRow(IDataRecord record)
        {
            lrlEleverVyer.Text += String.Format("{0}, {1}, {2}",record[0], record[1], record[2]) +"<br/>";
        }

       
        }
        }
    