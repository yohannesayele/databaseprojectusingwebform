﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                   if (!IsPostBack)
                {
                Database db = new Database();

                if (db.Connect())
                {
                    DataSet ds = new DataSet();
                    String queryString = "SELECT Enamn,Fnamn, Email, Gatuadress FROM ELEV order by Enamn";
                    ds = db.GetDataSet(queryString);

                    lrlStudents.Text = "<h1>Studenter</h1>";
                    lrlStudents.Text += "<table border='1'><tr>";
                    
                    foreach (DataColumn column in ds.Tables[0].Columns)
                    {
                        lrlStudents.Text += "<th>" + column.ColumnName + "</th>"; 

                    }
                    lrlStudents.Text += "</tr>";

                    foreach(DataRow row in ds.Tables[0].Rows)
                    {
                        lrlStudents.Text += "<tr><td>" + row["ENamn"] + "</td>" + 
                                           "<td>" + row["FNamn"] + "</td>" +
                                           "<td>" + row["EMAIL"] + "</td>" +
                                           "<td>" + row["Gatuadress"] + "</td></tr>";
                    }
                }
                else
                {
                    throw new Exception("Database connection error.");
                }
            }
        }
    }
        }
