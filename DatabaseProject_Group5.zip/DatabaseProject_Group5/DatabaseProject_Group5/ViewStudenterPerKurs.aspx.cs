﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace DatabaseProject_Group5
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        private Database db;

        protected void Page_Load(object sender, EventArgs e)
        {
            lblStudenterSaknas.Text = "";
            if (!IsPostBack)
            {
                db = new Database();

                SqlDataSource1.ConnectionString = db.GetConnectionString();

                // Fyll på persnr i dropdownlist
                fillCoursesToDropDownList();
            }
        }

        private void fillCoursesToDropDownList()
        {
            DataSet ds = new DataSet();
            String queryString = "SELECT kurskod, kursnamn FROM Kurs " +
                                 "ORDER BY kursnamn";
            ds = db.GetDataSet(queryString);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ListItem listItem = new ListItem();
                listItem.Value = row["kurskod"].ToString();
                listItem.Text = row["kursnamn"].ToString();
                ddlStudenter.Items.Add(listItem);
            }
        }

        protected void ddlStudenter_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataSource1.SelectCommand = "SELECT s.persnr, fnamn, enamn, kursnamn FROM Elev s, kurstillfället su, Kurs k " +
                                              "WHERE s.persnr = su.pernr " +
                                              "AND k.kurskod = su.kurskod " +
                                              "AND su.kurskod = '" + ddlStudenter.SelectedValue.ToString() + "' " +
                                              "ORDER BY enamn";
            if (db == null)
                db = new Database();
            SqlDataSource1.ConnectionString = db.GetConnectionString();
            dlstStudenter.DataSource = SqlDataSource1;
            dlstStudenter.DataBind();

            if (dlstStudenter.Items.Count == 0)
                lblStudenterSaknas.Text = "Det finns inga studenter registrerade på denna kurs.";

            // skriv ut kursnamn
            lblKursnamn.Text = "<h3>Kursnamn: " + ddlStudenter.SelectedItem.Text + "</h3>";
            lblKurskod.Text = "<h3>Kurskod: " + ddlStudenter.SelectedValue.ToString() + "</h3>";
         
        }
    }
}