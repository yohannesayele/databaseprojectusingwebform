﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace DatabaseProject_Group5
{
    public partial class WebForm5 : System.Web.UI.Page
    {
       private static Database db;
        protected void Page_Load(object sender, EventArgs e)
        {  
            
            if (!IsPostBack)
            {
                db = new Database();

                SqlDataSource1.ConnectionString = db.GetConnectionString();

                // Fyll på persnr i dropdownlist
                fillCoursesToDropDownList();
            }
        }

        private void fillCoursesToDropDownList()
        {
            ddlKurser.ClearSelection();
            ddlKurser.Items.Clear();
            DataSet ds = new DataSet();
            String queryString = "SELECT kurskod, kursnamn FROM Kurs " +
                                 "ORDER BY kursnamn";
            ds = db.GetDataSet(queryString);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ListItem listItem = new ListItem();
                listItem.Value = row["kurskod"].ToString();
                listItem.Text = row["kursnamn"].ToString();
                ddlKurser.Items.Add(listItem);
            }
        }

        protected void ddlKurser_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblStatus.Text = ""; // Rensa
            SqlDataSource1.ConnectionString = db.GetConnectionString();
            SqlDataSource1.SelectCommand = "SELECT * FROM KURS " +
                                           "WHERE kurskod = '" + ddlKurser.SelectedValue.ToString() + "'";
            detailsViewCourses.DataSource = SqlDataSource1;
            detailsViewCourses.DataBind();
        }

        
        protected void detailsViewCourses_ItemUpdating1(object sender, DetailsViewUpdateEventArgs e)
        {
            SqlDataSource1.UpdateCommand = "UPDATE Kurs SET " +
                                          "Kursnamn = '" + e.NewValues[1].ToString() + "', " +
                                          "Nivå = '" + e.NewValues[2] + "', " +
                                          "Poäng = '" + e.NewValues[3].ToString() + "' " +
                                          "WHERE kurskod = '" + ddlKurser.SelectedValue.ToString() + "'";
            if (db == null)
                db = new Database();

            SqlDataSource1.ConnectionString = db.GetConnectionString();
            SqlDataSource1.Update();
            SqlDataSource1.DataBind();
            fillCoursesToDropDownList();
            detailsViewCourses.DataSource = SqlDataSource1;
            detailsViewCourses.DataBind();
            detailsViewCourses.ChangeMode(DetailsViewMode.ReadOnly);
            lblStatus.Text = "Posten är uppdaterad. Välj ny kurs att uppdatera.";
        }
    }
}