﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        private static Database db;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                db = new Database();

                SqlDataSource1.ConnectionString = db.GetConnectionString();

                // Fyll på persnr i dropdownlist
                fillCoursesToDropDownList();
            }
        }

        private void fillCoursesToDropDownList()
        {
            ddlKurser.ClearSelection();
            ddlKurser.Items.Clear();
            DataSet ds = new DataSet();
            String queryString = "SELECT kurskod, kursnamn FROM Kurs " +
                                 "ORDER BY kursnamn";
            ds = db.GetDataSet(queryString);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ListItem listItem = new ListItem();
                listItem.Value = row["kurskod"].ToString();
                listItem.Text = row["kursnamn"].ToString();
                ddlKurser.Items.Add(listItem);
            }
        }

        protected void ddlKurser_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Database db = new Database();
                SqlDataReader reader = null;
                if (db.Connect())
                {
                    reader = db.GetDataReader("SELECT Elev.ENAMN,Elev.FNAMN, KURS.KURSNAMN,KURSTILLFÄLLET.NUMMERTRÄFFA, TILLFÄLLET.DATUM " +
                                    "FROM ELEV, KURS,KURSTILLFÄLLET,TILLFÄLLET " +
              "WHERE elev.PERSNR=KURSTILLFÄLLET.PERNR and KURSTILLFÄLLET.KURSKOD=kurs.KURSKOD and KURSTILLFÄLLET.KURSKOD=tillfället.KURSKOD and KURSTILLFÄLLET.PERNR=tillfället.PERNR and " +
              "kurs.KURSKOD= '" + ddlKurser.SelectedValue.ToString() + "'");
               
                }
                else
                {
                    throw new Exception("Database connection error.");
                }
                if (reader != null)
                {
                    lrlTillfället.Text = "<h2>Kurs närvaro </h2>";
                    while (reader.Read())
                    {
                        ReadSingleRow((IDataRecord)reader);
                    }
                }
                else
                {
                    lrlTillfället.Text = "Det finns ingen data!";
                }


            }
            catch(Exception ex) {
                lrlTillfället.Text = ex.Message;
            }
        }

        private void ReadSingleRow(IDataRecord record)
        {
            lrlTillfället.Text += String.Format("{0}, {1}, {2}, {3}, {4}", record[0], record[1], record[2], record[3], record[4]) + "<br/>";
        }
    }
}