﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowNärvarofråmVyer();
            }

        }

        private void ShowNärvarofråmVyer()
        {
            SqlDataReader rd = null;
           
            try
            {
                Database db = new Database();
                if (db.Connect())
                {
                    rd = db.GetDataReader("SELECT * FROM Närvaro_under_Average");
                }
                else
                {
                    throw new Exception("Database connection error.");
                }
                if (rd != null)
                {
                    lrlEleverNärvaro.Text = "<h2>närvaro i kursen mindre än halv</h2>";
                   
                    while (rd.Read())
                    {
                        ReadSingleRow((IDataRecord)rd);
                    }
                }
                else
                {
                    lrlEleverNärvaro.Text = "Det finns inga data";
                }
            }
            catch(Exception e)
            {
                lrlEleverNärvaro.Text = e.Message;
            }
        }

        private void ReadSingleRow(IDataRecord dataRecord)
        {
            lrlEleverNärvaro.Text = String.Format("{0}, {1}, {2}, {3} "+dataRecord[0],dataRecord[1],dataRecord[2],dataRecord[3],dataRecord[4]);
        }
    }
}