﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        { 
            // you need the image path this code to work according your image position
            string imaglocation = "C:\\Users\\Yohannes\\Pictures\\" + FileUpload1.FileName;
            byte[] img = null;
            FileStream fs = new FileStream(imaglocation, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);
            Database db = new Database();
            string queryString="Insert into Elev(persnr,enamn,fnamn,email,gatuadress,postnr,image) values (34,'"+TextBoxEnamn.Text+"','"+TextBoxFnamn.Text+"','"+TextBoxEmail.Text+"','"+TextBoxGatuadresss.Text+"' ,14152, @img)";
            using (SqlConnection connection = new SqlConnection(db.GetConnectionString()))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                command.Parameters.Add("@img", img);
                
                command.ExecuteNonQuery();
            }
        }
    }
}