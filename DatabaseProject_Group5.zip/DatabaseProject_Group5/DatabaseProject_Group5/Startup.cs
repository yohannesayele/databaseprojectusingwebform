﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DatabaseProject_Group5.Startup))]
namespace DatabaseProject_Group5
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
