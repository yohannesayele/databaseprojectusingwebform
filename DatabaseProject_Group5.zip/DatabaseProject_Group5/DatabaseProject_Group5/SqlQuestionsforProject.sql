﻿--to read the number of närvaro from the view
SELECT * FROM Antal_närvaro;
--to read the number of närvaro from the view less than half of the course requirment
SELECT * FROM Närvaro_under_Average
--närvaro per kurs uses these two questions
--SELECT kurskod, kursnamn FROM Kurs ORDER BY kursnamn
SELECT Elev.ENAMN,Elev.FNAMN, KURS.KURSNAMN,KURSTILLFÄLLET.NUMMERTRÄFFA, TILLFÄLLET.DATUM 
                                    FROM ELEV, KURS,KURSTILLFÄLLET,TILLFÄLLET 
              WHERE elev.PERSNR=KURSTILLFÄLLET.PERNR and KURSTILLFÄLLET.KURSKOD=kurs.KURSKOD and KURSTILLFÄLLET.KURSKOD=tillfället.KURSKOD and KURSTILLFÄLLET.PERNR=tillfället.PERNR and 
              kurs.KURSKOD= ' ddlKurser.SelectedValue.ToString() '
--to select studenter list using view
SELECT * FROM ELEVER_LISTA;

--view kurs
SELECT * FROM Kurs
--update kurs
SELECT kurskod, kursnamn FROM Kurs ORDER BY kursnamn;
SELECT * FROM KURS WHERE kurskod = ' ddlKurser.SelectedValue.ToString() '
UPDATE Kurs SET Kursnamn = ' e.NewValues[1].ToString() ',Nivå = 'e.NewValues[2] ', Poäng = ' e.NewValues[3].ToString() ' 
                                          WHERE kurskod = '" + ddlKurser.SelectedValue.ToString() ';

--to inser image and student information from user interface
Insert into Elev(persnr,enamn,fnamn,email,gatuadress,postnr,image) values (34,'"+TextBoxEnamn.Text+"','"+TextBoxFnamn.Text+"','"+TextBoxEmail.Text+"','"+TextBoxGatuadresss.Text+"' ,14152, @img);
--viewstudenter
SELECT Enamn,Fnamn, Email, Gatuadress FROM ELEV order by Enamn;
--viewstudenter pre kurs
SELECT kurskod, kursnamn FROM Kurs ORDER BY kursnamn
SELECT s.persnr, fnamn, enamn, kursnamn FROM Elev s, kurstillfället su, Kurs k WHERE s.persnr = su.pernr AND k.kurskod = su.kurskod AND su.kurskod = ' ddlStudenter.SelectedValue.ToString() ' ORDER BY enamn;

--view studentuppgift
SELECT  enamn, kursnamn, poäng, nivå ,betyg FROM Elev s, kurstillfället su, Kurs k  WHERE s.persnr = su.pernr AND k.kurskod = su.kurskod  ORDER BY enamn, fnamn,kursnamn, poäng, nivå ,betyg;
