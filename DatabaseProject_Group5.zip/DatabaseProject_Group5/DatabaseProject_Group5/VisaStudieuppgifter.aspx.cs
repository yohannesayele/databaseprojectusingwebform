﻿using DatabaseProject_Group5.DatabaseConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProject_Group5
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Database db = new Database();

            SqlDataSource1.ConnectionString = db.GetConnectionString();
            SqlDataSource1.SelectCommand = "SELECT fnamn, enamn, kursnamn, poäng, nivå ,betyg FROM Elev s, kurstillfället su, Kurs k " +
                                           "WHERE s.persnr = su.pernr " +
                                           "AND k.kurskod = su.kurskod " +
                                           "ORDER BY enamn";
            gridViewStudieuppgifter.DataBind();
        }
    }
}