﻿using System.Web.UI;

namespace DatabaseProject_Group5.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}